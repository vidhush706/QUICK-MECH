/**
 * QUICK MECH - Single Page Application Core
 * Connects frontend views with Java REST API
 */

const API_BASE = '/api';

const state = {
  role: 'user', // 'user', 'provider', 'admin', 'project'
  userId: 1,
  providerId: 101,
  vehicles: [],
  selectedVehicleId: null,
  serviceType: 'REPAIR',
  subService: 'Flat Tyre / Puncture Repair',
  repairBasePrice: 350,
  fuelType: 'Petrol',
  fuelQuantity: 5,
  fuelUnitPrice: 104.50,
  activeBooking: null,
  allBookings: [],
  allProviders: [],
  adminStats: null,
  ratingVal: 5,
  routeInterval: null
};

// Initialize on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  setupServiceSelectors();
  setupModals();
  loadInitialData();

  // Polling for active updates
  setInterval(() => {
    if (state.activeBooking && state.activeBooking.status !== 'COMPLETED' && state.activeBooking.status !== 'CANCELLED') {
      refreshActiveBooking(state.activeBooking.bookingId);
    }
  }, 3500);
});

/* ==========================================================================
   Navigation & Role Switcher
   ========================================================================== */
function setupNavigation() {
  const roleButtons = document.querySelectorAll('.role-btn');
  roleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetRole = btn.dataset.role;
      switchRole(targetRole);
    });
  });

  // Provider profile switcher in provider tab
  const provSelect = document.getElementById('providerProfileSelect');
  if (provSelect) {
    provSelect.addEventListener('change', (e) => {
      state.providerId = parseInt(e.target.value);
      loadProviderDashboard();
    });
  }
}

function switchRole(role) {
  state.role = role;
  document.querySelectorAll('.role-btn').forEach(b => b.classList.toggle('active', b.dataset.role === role));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.toggle('active', p.id === `${role}-pane`));

  if (role === 'user') {
    loadUserDashboard();
  } else if (role === 'provider') {
    loadProviderDashboard();
  } else if (role === 'admin') {
    loadAdminDashboard();
  } else if (role === 'project') {
    // Project Presentation view
  }
}

/* ==========================================================================
   Data Loading
   ========================================================================== */
async function loadInitialData() {
  await loadVehicles();
  await loadProviders();
  await loadUserBookings();
  updateCostPreview();
}

async function loadVehicles() {
  try {
    const res = await fetch(`${API_BASE}/vehicles?userId=${state.userId}`);
    state.vehicles = await res.json();
    renderVehicles();
  } catch (err) {
    console.error('Failed to load vehicles:', err);
  }
}

async function loadProviders() {
  try {
    const res = await fetch(`${API_BASE}/providers`);
    state.allProviders = await res.json();
    renderProvidersList();
  } catch (err) {
    console.error('Failed to load providers:', err);
  }
}

async function loadUserBookings() {
  try {
    const res = await fetch(`${API_BASE}/bookings?userId=${state.userId}`);
    state.allBookings = await res.json();
    renderBookingsHistory();

    // Check if there is an active (in-progress) booking
    const active = state.allBookings.find(b => b.status !== 'COMPLETED' && b.status !== 'CANCELLED');
    if (active) {
      state.activeBooking = active;
      renderActiveBooking(active);
    } else if (state.allBookings.length > 0) {
      // Show most recent completed
      state.activeBooking = state.allBookings[0];
      renderActiveBooking(state.activeBooking);
    }
  } catch (err) {
    console.error('Failed to load bookings:', err);
  }
}

/* ==========================================================================
   Service Form & Calculator
   ========================================================================== */
function setupServiceSelectors() {
  // Toggle between Repair & Fuel
  const toggleRepair = document.getElementById('toggleRepair');
  const toggleFuel = document.getElementById('toggleFuel');
  const repairOptions = document.getElementById('repairOptionsSection');
  const fuelOptions = document.getElementById('fuelOptionsSection');

  if (toggleRepair && toggleFuel) {
    toggleRepair.addEventListener('click', () => {
      state.serviceType = 'REPAIR';
      toggleRepair.classList.add('active');
      toggleFuel.classList.remove('active');
      repairOptions.style.display = 'block';
      fuelOptions.style.display = 'none';
      updateCostPreview();
    });

    toggleFuel.addEventListener('click', () => {
      state.serviceType = 'FUEL_DELIVERY';
      toggleFuel.classList.add('active');
      toggleRepair.classList.remove('active');
      repairOptions.style.display = 'none';
      fuelOptions.style.display = 'block';
      updateCostPreview();
    });
  }

  // Repair item selection
  document.querySelectorAll('.service-item-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.service-item-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      state.subService = card.dataset.service;
      state.repairBasePrice = parseFloat(card.dataset.price);
      updateCostPreview();
    });
  });

  // Fuel Type selection
  const fuelTypeSelect = document.getElementById('fuelTypeSelect');
  if (fuelTypeSelect) {
    fuelTypeSelect.addEventListener('change', (e) => {
      state.fuelType = e.target.value;
      state.fuelUnitPrice = state.fuelType === 'Diesel' ? 92.80 : 104.50;
      updateCostPreview();
    });
  }

  // Fuel Litres Slider
  const fuelSlider = document.getElementById('fuelLitresSlider');
  const fuelLitresDisplay = document.getElementById('fuelLitresDisplay');
  if (fuelSlider) {
    fuelSlider.addEventListener('input', (e) => {
      state.fuelQuantity = parseFloat(e.target.value);
      if (fuelLitresDisplay) fuelLitresDisplay.textContent = `${state.fuelQuantity} Litres`;
      updateCostPreview();
    });
  }

  // Quick Litre buttons
  document.querySelectorAll('.quick-litre-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.quick-litre-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.fuelQuantity = parseFloat(btn.dataset.litres);
      if (fuelSlider) fuelSlider.value = state.fuelQuantity;
      if (fuelLitresDisplay) fuelLitresDisplay.textContent = `${state.fuelQuantity} Litres`;
      updateCostPreview();
    });
  });

  // Form Submit
  const requestForm = document.getElementById('serviceRequestForm');
  if (requestForm) {
    requestForm.addEventListener('submit', handleServiceBookingSubmit);
  }

  // Quick Location buttons
  document.querySelectorAll('.location-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const locInput = document.getElementById('serviceLocation');
      if (locInput) locInput.value = chip.dataset.location;
    });
  });
}

function updateCostPreview() {
  let base = 0;
  let fuelCost = 0;

  if (state.serviceType === 'REPAIR') {
    base = state.repairBasePrice;
  } else {
    base = 150.0; // Delivery surcharge
    fuelCost = state.fuelQuantity * state.fuelUnitPrice;
  }

  const subtotal = base + fuelCost;
  const tax = subtotal * 0.18;
  const total = subtotal + tax;

  const costBreakdown = document.getElementById('costBreakdown');
  if (costBreakdown) {
    costBreakdown.innerHTML = `
      <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:0.85rem;">
        <span>${state.serviceType === 'REPAIR' ? 'Repair Base Fee' : 'Express Delivery Fee'}:</span>
        <strong>₹${base.toFixed(2)}</strong>
      </div>
      ${state.serviceType === 'FUEL_DELIVERY' ? `
      <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:0.85rem;">
        <span>Fuel (${state.fuelQuantity}L @ ₹${state.fuelUnitPrice}/L):</span>
        <strong>₹${fuelCost.toFixed(2)}</strong>
      </div>` : ''}
      <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:0.85rem; color:#6c757d;">
        <span>GST (18%):</span>
        <span>₹${tax.toFixed(2)}</span>
      </div>
      <div style="display:flex; justify-content:space-between; margin-top:8px; padding-top:8px; border-top:1px dashed #dee2e6; font-size:1.05rem; font-weight:bold; color:#d9480f;">
        <span>Estimated Total:</span>
        <span>₹${total.toFixed(2)}</span>
      </div>
    `;
  }
}

/* ==========================================================================
   Booking Actions & API Calls
   ========================================================================== */
async function handleServiceBookingSubmit(e) {
  e.preventDefault();

  const vehicleSelect = document.getElementById('vehicleSelect');
  const locationInput = document.getElementById('serviceLocation');
  const notesInput = document.getElementById('serviceNotes');

  const vehicleId = vehicleSelect ? parseInt(vehicleSelect.value) : (state.vehicles[0]?.vehicleId || 1);
  const location = locationInput?.value?.trim() || 'Mattanur Airport Road, Kannur';
  const notes = notesInput?.value?.trim() || '';

  const payload = {
    userId: state.userId,
    vehicleId: vehicleId,
    serviceType: state.serviceType,
    subService: state.serviceType === 'REPAIR' ? state.subService : `${state.fuelQuantity}L ${state.fuelType} Emergency Delivery`,
    fuelType: state.serviceType === 'FUEL_DELIVERY' ? state.fuelType : 'None',
    fuelQuantity: state.serviceType === 'FUEL_DELIVERY' ? state.fuelQuantity : 0,
    location: location,
    latitude: 11.9215 + (Math.random() - 0.5) * 0.015,
    longitude: 75.5780 + (Math.random() - 0.5) * 0.015,
    notes: notes
  };

  const btn = e.target.querySelector('button[type="submit"]');
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⚡ Dispatching Nearest Provider...';
  }

  try {
    const res = await fetch(`${API_BASE}/bookings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();

    if (result.success) {
      state.activeBooking = result.booking;
      renderActiveBooking(result.booking);
      showToast('Booking Dispatched! Nearest provider assigned.', 'success');
      loadUserBookings();

      // Scroll to live tracker
      document.getElementById('liveTrackerCard')?.scrollIntoView({ behavior: 'smooth' });
    } else {
      showToast(result.error || 'Failed to dispatch', 'error');
    }
  } catch (err) {
    console.error('Error creating booking:', err);
    showToast('Failed to connect to Quick Mech server', 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '🚀 Request Immediate Dispatch';
    }
  }
}

async function refreshActiveBooking(bookingId) {
  try {
    const res = await fetch(`${API_BASE}/bookings/${bookingId}`);
    if (res.ok) {
      const data = await res.json();
      state.activeBooking = data;
      renderActiveBooking(data);
    }
  } catch (err) {
    console.error('Failed to refresh booking:', err);
  }
}

/* ==========================================================================
   Render Active Booking & Live Tracker Pipeline
   ========================================================================== */
function renderActiveBooking(booking) {
  const trackerCard = document.getElementById('liveTrackerCard');
  if (!trackerCard) return;

  if (!booking) {
    trackerCard.style.display = 'none';
    return;
  }

  trackerCard.style.display = 'block';

  // Booking Details
  document.getElementById('trackBookingId').textContent = `#BK-${booking.bookingId}`;
  document.getElementById('trackServiceType').textContent = `${booking.serviceType}: ${booking.subService || ''}`;
  document.getElementById('trackLocation').textContent = booking.location;
  document.getElementById('trackEta').textContent = booking.estimatedArrival || 'Assigned';
  document.getElementById('trackAmount').textContent = `₹${parseFloat(booking.totalAmount).toFixed(2)}`;

  // Provider Card
  const provName = booking.providerName || (booking.provider ? booking.provider.name : 'Assigned Provider');
  const provPhone = booking.providerPhone || (booking.provider ? booking.provider.phone : '9847234567');
  document.getElementById('trackProviderName').textContent = provName;
  document.getElementById('trackProviderPhone').textContent = provPhone;

  // OTP Display (Slide 6 & 9)
  const otpBox = document.getElementById('trackOtpBox');
  const otpPin = booking.otpPin || '482910';
  document.getElementById('trackOtpCode').textContent = `${otpPin.slice(0,3)} ${otpPin.slice(3)}`;

  // Update Stepper Pipeline
  const statusSteps = ['REQUESTED', 'ASSIGNED', 'EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'COMPLETED'];
  const currentIdx = statusSteps.indexOf(booking.status.toUpperCase());

  const progressPercent = Math.max(5, (Math.max(0, currentIdx) / (statusSteps.length - 1)) * 100);
  const progressBar = document.getElementById('stepperProgressBar');
  if (progressBar) progressBar.style.width = `${progressPercent}%`;

  statusSteps.forEach((st, idx) => {
    const stepEl = document.getElementById(`step-${st.toLowerCase()}`);
    if (stepEl) {
      stepEl.classList.remove('completed', 'active');
      if (idx < currentIdx) {
        stepEl.classList.add('completed');
      } else if (idx === currentIdx) {
        stepEl.classList.add('active');
      }
    }
  });

  // Action Buttons according to status
  const actionsContainer = document.getElementById('trackerActionControls');
  if (actionsContainer) {
    let html = '';

    if (booking.status === 'ASSIGNED') {
      html += `<button class="btn btn-sm btn-outline" onclick="simulateStatusUpdate(${booking.bookingId}, 'EN_ROUTE')">🚗 Simulate Provider En Route</button>`;
    } else if (booking.status === 'EN_ROUTE') {
      html += `<button class="btn btn-sm btn-outline" onclick="simulateStatusUpdate(${booking.bookingId}, 'ARRIVED')">📍 Simulate Provider Arrived</button>`;
    } else if (booking.status === 'ARRIVED') {
      html += `<button class="btn btn-sm btn-primary" onclick="openOtpVerifyModal(${booking.bookingId})">🔑 Verify OTP to Start Job</button>`;
    } else if (booking.status === 'IN_PROGRESS') {
      html += `<button class="btn btn-sm btn-success" onclick="simulateStatusUpdate(${booking.bookingId}, 'COMPLETED')">✅ Complete Service & Bill</button>`;
    } else if (booking.status === 'COMPLETED') {
      if (booking.paymentStatus !== 'PAID') {
        html += `<button class="btn btn-sm btn-primary" onclick="openPaymentModal(${booking.bookingId}, ${booking.totalAmount})">💳 Pay Now (₹${booking.totalAmount})</button>`;
      } else {
        html += `<button class="btn btn-sm btn-secondary" onclick="openInvoiceModal(${booking.bookingId})">📄 View Tax Invoice</button>`;
        html += `<button class="btn btn-sm btn-outline" onclick="openFeedbackModal(${booking.bookingId})">⭐ Rate Service</button>`;
      }
    }

    actionsContainer.innerHTML = html;
  }

  // Update Visual Map Simulation
  drawMapSimulation(booking.status);
}

/* ==========================================================================
   Live Simulated Map Drawing
   ========================================================================== */
function drawMapSimulation(status) {
  const mapSvg = document.getElementById('mapSvgCanvas');
  if (!mapSvg) return;

  let carPos = { x: 90, y: 190 };
  let statusText = 'Provider dispatched from depot';

  if (status === 'ASSIGNED') {
    carPos = { x: 100, y: 180 };
    statusText = 'Provider assigned • Preparing tools & vehicle';
  } else if (status === 'EN_ROUTE') {
    carPos = { x: 240, y: 130 };
    statusText = 'Provider is on the way (En Route) • ETA 8 mins';
  } else if (status === 'ARRIVED') {
    carPos = { x: 340, y: 90 };
    statusText = 'Provider has arrived at your breakdown location!';
  } else if (status === 'IN_PROGRESS') {
    carPos = { x: 350, y: 80 };
    statusText = 'Service in progress on-site (OTP Verified)';
  } else if (status === 'COMPLETED') {
    carPos = { x: 350, y: 80 };
    statusText = 'Service successfully completed!';
  }

  mapSvg.innerHTML = `
    <!-- Roads Background -->
    <rect width="100%" height="100%" fill="#e8eee9" />
    <!-- Rivers/Canal -->
    <path d="M 0 240 Q 200 200 450 260" stroke="#b2d8d8" stroke-width="14" fill="none" />
    <!-- Secondary Roads -->
    <path d="M 50 0 L 50 300 M 200 0 L 200 300 M 350 0 L 350 300" stroke="#ffffff" stroke-width="6" />
    <path d="M 0 100 L 500 100 M 0 200 L 500 200" stroke="#ffffff" stroke-width="6" />
    <!-- Main Route Line -->
    <path d="M 80 200 Q 220 180 350 80" stroke="#1971c2" stroke-width="5" stroke-dasharray="6,4" fill="none" />
    <!-- Destination (Customer Breakdown Spot) -->
    <circle cx="350" cy="80" r="14" fill="#d9480f" opacity="0.3" />
    <circle cx="350" cy="80" r="8" fill="#d9480f" />
    <text x="350" y="60" text-anchor="middle" font-size="11" font-weight="bold" fill="#d9480f">📍 Breakdown (You)</text>
    <!-- Moving Service Vehicle -->
    <circle cx="${carPos.x}" cy="${carPos.y}" r="12" fill="#2b8a3e" />
    <text x="${carPos.x}" y="${carPos.y + 4}" text-anchor="middle" font-size="12" fill="#ffffff">🛠️</text>
    <text x="${carPos.x}" y="${carPos.y + 22}" text-anchor="middle" font-size="10" font-weight="bold" fill="#2b8a3e">Provider</text>
  `;

  const mapStatusMsg = document.getElementById('mapStatusMessage');
  if (mapStatusMsg) mapStatusMsg.textContent = statusText;
}

/* ==========================================================================
   Simulation Helper for Testing Pipeline
   ========================================================================== */
async function simulateStatusUpdate(bookingId, newStatus) {
  try {
    const res = await fetch(`${API_BASE}/bookings/${bookingId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });
    const result = await res.json();
    if (result.success) {
      showToast(`Status updated to: ${newStatus}`, 'info');
      refreshActiveBooking(bookingId);
      loadUserBookings();
    }
  } catch (err) {
    console.error('Failed to update status:', err);
  }
}

/* ==========================================================================
   User Garage (Vehicle Management)
   ========================================================================== */
function renderVehicles() {
  const container = document.getElementById('userVehiclesList');
  const selector = document.getElementById('vehicleSelect');

  if (selector) {
    selector.innerHTML = state.vehicles.map(v => `
      <option value="${v.vehicleId}">${v.brand} ${v.model} (${v.vehicleNumber}) - ${v.vehicleType}</option>
    `).join('');
  }

  if (container) {
    if (state.vehicles.length === 0) {
      container.innerHTML = `<p style="color:#6c757d; font-size:0.9rem;">No vehicles registered. Add your vehicle to begin.</p>`;
      return;
    }

    container.innerHTML = state.vehicles.map(v => `
      <div style="background:#fff; border:1px solid #e9ecef; border-radius:8px; padding:10px 14px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div style="font-weight:bold; font-size:0.95rem; display:flex; align-items:center; gap:6px;">
            <span>${v.vehicleType === 'Two-Wheeler' ? '🏍️' : '🚗'}</span>
            ${v.brand} ${v.model}
          </div>
          <div style="font-size:0.8rem; color:#6c757d; font-family:monospace; font-weight:600;">
            ${v.vehicleNumber} • <span class="badge badge-info">${v.vehicleType}</span>
          </div>
        </div>
        <button class="btn btn-sm btn-outline" style="color:#e03131;" onclick="deleteVehicle(${v.vehicleId})">🗑️</button>
      </div>
    `).join('');
  }
}

async function handleAddVehicleSubmit(e) {
  e.preventDefault();
  const num = document.getElementById('newVehicleNumber').value.trim();
  const type = document.getElementById('newVehicleType').value;
  const brand = document.getElementById('newVehicleBrand').value.trim();
  const model = document.getElementById('newVehicleModel').value.trim();

  try {
    const res = await fetch(`${API_BASE}/vehicles`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: state.userId,
        vehicleNumber: num,
        vehicleType: type,
        brand: brand,
        model: model
      })
    });
    const result = await res.json();
    if (result.success) {
      closeModal('addVehicleModal');
      showToast('Vehicle added to garage!', 'success');
      loadVehicles();
      e.target.reset();
    }
  } catch (err) {
    console.error('Error adding vehicle:', err);
  }
}

async function deleteVehicle(vehicleId) {
  if (!confirm('Remove this vehicle?')) return;
  try {
    await fetch(`${API_BASE}/vehicles/${vehicleId}`, { method: 'DELETE' });
    showToast('Vehicle removed', 'info');
    loadVehicles();
  } catch (err) {
    console.error('Error removing vehicle:', err);
  }
}

/* ==========================================================================
   Provider Portal Operations
   ========================================================================== */
async function loadProviderDashboard() {
  try {
    // Load provider details
    const resP = await fetch(`${API_BASE}/providers`);
    const allP = await resP.json();
    const currentP = allP.find(p => p.providerId === state.providerId) || allP[0];

    if (currentP) {
      document.getElementById('providerNameDisplay').textContent = currentP.name;
      document.getElementById('providerTypeDisplay').textContent = currentP.providerType;
      document.getElementById('providerRatingDisplay').textContent = `${currentP.rating} ★ (${currentP.ratingCount} reviews)`;
      document.getElementById('providerLocationDisplay').textContent = currentP.location;

      const toggleBtn = document.getElementById('providerAvailabilityToggle');
      if (toggleBtn) {
        toggleBtn.textContent = currentP.availability ? 'Online (Available)' : 'Offline (Busy)';
        toggleBtn.className = `btn btn-sm ${currentP.availability ? 'btn-success' : 'btn-outline'}`;
      }
    }

    // Load assigned bookings for this provider
    const resB = await fetch(`${API_BASE}/bookings?providerId=${state.providerId}`);
    const bookings = await resB.json();
    renderProviderJobs(bookings);
  } catch (err) {
    console.error('Error loading provider dashboard:', err);
  }
}

async function toggleProviderAvailability() {
  try {
    const res = await fetch(`${API_BASE}/providers/toggle-availability`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ providerId: state.providerId })
    });
    const result = await res.json();
    if (result.success) {
      showToast(`Availability updated to ${result.provider.availability ? 'Online' : 'Offline'}`, 'info');
      loadProviderDashboard();
    }
  } catch (err) {
    console.error('Error toggling availability:', err);
  }
}

function renderProviderJobs(jobs) {
  const container = document.getElementById('providerJobsList');
  if (!container) return;

  if (jobs.length === 0) {
    container.innerHTML = `
      <div style="text-align:center; padding:2rem; color:#6c757d;">
        <span style="font-size:2rem; display:block; margin-bottom:8px;">🏖️</span>
        No assigned jobs right now. Stay online to receive on-demand requests.
      </div>
    `;
    return;
  }

  container.innerHTML = jobs.map(job => {
    let actionBtn = '';
    if (job.status === 'ASSIGNED') {
      actionBtn = `<button class="btn btn-sm btn-primary" onclick="simulateStatusUpdate(${job.bookingId}, 'EN_ROUTE')">🚗 Start Trip (En Route)</button>`;
    } else if (job.status === 'EN_ROUTE') {
      actionBtn = `<button class="btn btn-sm btn-secondary" onclick="simulateStatusUpdate(${job.bookingId}, 'ARRIVED')">📍 Mark Arrived</button>`;
    } else if (job.status === 'ARRIVED') {
      actionBtn = `<button class="btn btn-sm btn-warning" onclick="openOtpVerifyModal(${job.bookingId})">🔑 Enter Customer OTP PIN</button>`;
    } else if (job.status === 'IN_PROGRESS') {
      actionBtn = `<button class="btn btn-sm btn-success" onclick="simulateStatusUpdate(${job.bookingId}, 'COMPLETED')">✅ Complete Service</button>`;
    } else if (job.status === 'COMPLETED') {
      actionBtn = `<span class="badge badge-success">Finished & Billed</span>`;
    }

    return `
      <div class="card" style="margin-bottom:1rem; border-left: 4px solid #d9480f;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.75rem;">
          <div>
            <h4 style="margin:0; font-size:1.05rem;">${job.serviceType}: ${job.subService || ''}</h4>
            <span style="font-size:0.8rem; color:#6c757d;">Booking #${job.bookingId} • ${job.bookingDate} ${job.bookingTime}</span>
          </div>
          <span class="badge ${getStatusBadgeClass(job.status)}">${job.status}</span>
        </div>
        <div style="font-size:0.88rem; margin-bottom:0.75rem; line-height:1.6;">
          <div><strong>Customer:</strong> ${job.userName} (📞 ${job.userPhone})</div>
          <div><strong>Vehicle:</strong> ${job.vehicleInfo}</div>
          <div><strong>Location:</strong> ${job.location}</div>
          <div><strong>Payout:</strong> ₹${parseFloat(job.totalAmount).toFixed(2)} (${job.paymentStatus})</div>
        </div>
        <div style="display:flex; gap:8px; justify-content:flex-end;">
          ${actionBtn}
        </div>
      </div>
    `;
  }).join('');
}

/* ==========================================================================
   Admin Operations (Slide 10)
   ========================================================================== */
async function loadAdminDashboard() {
  try {
    const resO = await fetch(`${API_BASE}/admin/overview`);
    const stats = await resO.json();
    state.adminStats = stats;

    document.getElementById('adminStatBookings').textContent = stats.totalBookings;
    document.getElementById('adminStatActive').textContent = stats.activeBookings;
    document.getElementById('adminStatRevenue').textContent = `₹${parseFloat(stats.totalRevenue).toLocaleString()}`;
    document.getElementById('adminStatProviders').textContent = `${stats.availableProviders}/${stats.totalProviders} Active`;

    // Load all bookings
    const resB = await fetch(`${API_BASE}/bookings`);
    const bookings = await resB.json();
    renderAdminBookingsTable(bookings);
  } catch (err) {
    console.error('Error loading admin dashboard:', err);
  }
}

function renderAdminBookingsTable(bookings) {
  const tbody = document.getElementById('adminBookingsTbody');
  if (!tbody) return;

  tbody.innerHTML = bookings.map(b => `
    <tr>
      <td><strong>#${b.bookingId}</strong></td>
      <td>${b.userName}<br><small style="color:#6c757d;">${b.userPhone}</small></td>
      <td>${b.serviceType}<br><small style="color:#d9480f;">${b.subService || ''}</small></td>
      <td>${b.providerName}</td>
      <td><span class="badge ${getStatusBadgeClass(b.status)}">${b.status}</span></td>
      <td>₹${parseFloat(b.totalAmount).toFixed(2)}<br><small style="color:${b.paymentStatus === 'PAID' ? '#2b8a3e' : '#f59f00'}">${b.paymentStatus}</small></td>
      <td>
        <button class="btn btn-sm btn-outline" onclick="openReassignModal(${b.bookingId})">Re-assign</button>
      </td>
    </tr>
  `).join('');
}

async function handleReassignSubmit(e) {
  e.preventDefault();
  const bookingId = parseInt(document.getElementById('reassignBookingId').value);
  const providerId = parseInt(document.getElementById('reassignProviderSelect').value);

  try {
    const res = await fetch(`${API_BASE}/admin/reassign`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bookingId, providerId })
    });
    const result = await res.json();
    if (result.success) {
      closeModal('reassignModal');
      showToast('Provider re-assigned successfully', 'success');
      loadAdminDashboard();
    }
  } catch (err) {
    console.error('Error reassigning provider:', err);
  }
}

async function resetSystemDemo() {
  if (!confirm('Reset Quick Mech demo data to initial presentation state?')) return;
  try {
    const res = await fetch(`${API_BASE}/system/reset`, { method: 'POST' });
    const result = await res.json();
    if (result.success) {
      showToast('System data reset to presentation defaults!', 'success');
      loadInitialData();
      if (state.role === 'admin') loadAdminDashboard();
      if (state.role === 'provider') loadProviderDashboard();
    }
  } catch (err) {
    console.error('Error resetting demo:', err);
  }
}

/* ==========================================================================
   OTP Verification (Slide 6, 7, 9)
   ========================================================================== */
function openOtpVerifyModal(bookingId) {
  document.getElementById('otpVerifyBookingId').value = bookingId;
  document.getElementById('otpPinInput').value = '';
  document.getElementById('otpVerifyError').style.display = 'none';
  openModal('otpVerifyModal');
}

async function handleOtpVerifySubmit(e) {
  e.preventDefault();
  const bookingId = parseInt(document.getElementById('otpVerifyBookingId').value);
  const pin = document.getElementById('otpPinInput').value.trim();
  const errorEl = document.getElementById('otpVerifyError');

  try {
    const res = await fetch(`${API_BASE}/bookings/${bookingId}/verify-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ otpPin: pin })
    });
    const result = await res.json();

    if (result.success && result.verified) {
      closeModal('otpVerifyModal');
      showToast('✅ OTP Verified Successfully! Service is now In Progress.', 'success');
      refreshActiveBooking(bookingId);
      loadUserBookings();
      if (state.role === 'provider') loadProviderDashboard();
    } else {
      errorEl.textContent = result.message || 'Invalid PIN code. Please verify and try again.';
      errorEl.style.display = 'block';
    }
  } catch (err) {
    console.error('Error verifying OTP:', err);
  }
}

/* ==========================================================================
   Payment Modal (Slide 6, 9)
   ========================================================================== */
function openPaymentModal(bookingId, amount) {
  document.getElementById('paymentBookingId').value = bookingId;
  document.getElementById('paymentAmountDisplay').textContent = `₹${parseFloat(amount).toFixed(2)}`;
  openModal('paymentModal');
}

async function handlePaymentSubmit(e) {
  e.preventDefault();
  const bookingId = parseInt(document.getElementById('paymentBookingId').value);
  const method = document.querySelector('input[name="paymentMethodRadio"]:checked')?.value || 'UPI';

  const btn = e.target.querySelector('button[type="submit"]');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Processing Payment...';
  }

  try {
    const res = await fetch(`${API_BASE}/bookings/${bookingId}/pay`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentMethod: method })
    });
    const result = await res.json();

    if (result.success) {
      closeModal('paymentModal');
      showToast('Payment Completed Successfully! Digital Invoice Generated.', 'success');
      refreshActiveBooking(bookingId);
      loadUserBookings();

      // Open Invoice Modal
      openInvoiceModal(bookingId);
    } else {
      showToast('Payment Failed', 'error');
    }
  } catch (err) {
    console.error('Error processing payment:', err);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Pay Now';
    }
  }
}

/* ==========================================================================
   Digital Invoice Modal (Slide 6, 7, 9)
   ========================================================================== */
async function openInvoiceModal(bookingId) {
  try {
    const res = await fetch(`${API_BASE}/bookings/${bookingId}`);
    const data = await res.json();
    const inv = data.invoice;

    if (!inv) {
      showToast('Invoice is being generated...', 'info');
      return;
    }

    const container = document.getElementById('invoiceContent');
    container.innerHTML = `
      <div class="invoice-box" id="printableInvoice">
        <div class="invoice-header">
          <div>
            <h2 style="color:#d9480f; margin:0; font-size:1.5rem; font-weight:800;">QUICK MECH</h2>
            <div style="font-size:0.8rem; color:#6c757d;">Integrated On-Demand Automotive & Fuel Delivery</div>
            <div style="font-size:0.75rem; color:#adb5bd;">STM College of Engg & Tech Project Hub • Kannur, Kerala</div>
          </div>
          <div style="text-align:right;">
            <div style="font-size:1.1rem; font-weight:bold; color:#212529;">TAX INVOICE</div>
            <div style="font-size:0.85rem; font-family:monospace; color:#d9480f;">${inv.invoiceNumber}</div>
            <div style="font-size:0.75rem; color:#6c757d;">Date: ${inv.invoiceDate}</div>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; margin-bottom:1.5rem; font-size:0.85rem;">
          <div>
            <strong style="color:#495057;">CUSTOMER DETAILS:</strong>
            <div>Name: <strong>${inv.customerName}</strong></div>
            <div>Phone: ${inv.customerPhone}</div>
            <div>Vehicle: ${inv.vehicleInfo}</div>
          </div>
          <div>
            <strong style="color:#495057;">SERVICE PROVIDER:</strong>
            <div>Provider: <strong>${inv.providerName}</strong></div>
            <div>Payment: <span class="badge badge-success">${inv.paymentMethod} • ${inv.paymentStatus}</span></div>
          </div>
        </div>

        <table style="width:100%; border-collapse:collapse; margin-bottom:1.5rem; font-size:0.88rem;">
          <thead>
            <tr style="border-bottom:2px solid #dee2e6; text-align:left;">
              <th style="padding:8px 0;">Item Description</th>
              <th style="padding:8px 0; text-align:right;">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom:1px solid #f1f3f5;">
              <td style="padding:8px 0;">${inv.serviceDescription}</td>
              <td style="padding:8px 0; text-align:right;">₹${parseFloat(inv.baseServiceFee).toFixed(2)}</td>
            </tr>
            ${inv.fuelCharges > 0 ? `
            <tr style="border-bottom:1px solid #f1f3f5;">
              <td style="padding:8px 0;">Emergency Fuel Dispensing Charges</td>
              <td style="padding:8px 0; text-align:right;">₹${parseFloat(inv.fuelCharges).toFixed(2)}</td>
            </tr>` : ''}
            <tr style="border-bottom:1px solid #f1f3f5;">
              <td style="padding:8px 0;">Emergency Roadside Dispatch Surcharge</td>
              <td style="padding:8px 0; text-align:right;">₹${parseFloat(inv.emergencySurcharge).toFixed(2)}</td>
            </tr>
            <tr style="border-bottom:1px solid #f1f3f5;">
              <td style="padding:8px 0; color:#6c757d;">GST / Taxes (18%)</td>
              <td style="padding:8px 0; text-align:right; color:#6c757d;">₹${parseFloat(inv.taxAmount).toFixed(2)}</td>
            </tr>
            <tr style="border-top:2px solid #212529; font-weight:bold; font-size:1.05rem;">
              <td style="padding:10px 0;">Grand Total Paid</td>
              <td style="padding:10px 0; text-align:right; color:#d9480f;">₹${parseFloat(inv.totalAmount).toFixed(2)}</td>
            </tr>
          </tbody>
        </table>

        <div style="background:#f8f9fa; border-radius:6px; padding:10px; font-size:0.75rem; color:#6c757d; text-align:center;">
          ✓ This is an authentic digital invoice generated by Quick Mech Automated Billing Engine.
        </div>
      </div>
    `;

    openModal('invoiceModal');
  } catch (err) {
    console.error('Error fetching invoice:', err);
  }
}

function printInvoice() {
  const printContent = document.getElementById('printableInvoice');
  if (!printContent) return;
  const win = window.open('', '', 'width=800,height=600');
  win.document.write(`<html><head><title>Quick Mech Invoice</title><style>body{font-family:sans-serif;padding:20px;}</style></head><body>${printContent.innerHTML}</body></html>`);
  win.document.close();
  win.print();
}

/* ==========================================================================
   Feedback & Rating Modal (Slide 6, 9)
   ========================================================================== */
function openFeedbackModal(bookingId) {
  document.getElementById('feedbackBookingId').value = bookingId;
  document.getElementById('feedbackComments').value = '';
  setStarRating(5);
  openModal('feedbackModal');
}

function setStarRating(num) {
  state.ratingVal = num;
  document.querySelectorAll('.star-rating .star').forEach(star => {
    const val = parseInt(star.dataset.val);
    star.classList.toggle('selected', val <= num);
  });
}

async function handleFeedbackSubmit(e) {
  e.preventDefault();
  const bookingId = parseInt(document.getElementById('feedbackBookingId').value);
  const comments = document.getElementById('feedbackComments').value.trim();

  try {
    const res = await fetch(`${API_BASE}/feedback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        bookingId: bookingId,
        rating: state.ratingVal,
        comments: comments || 'Great prompt assistance!'
      })
    });
    const result = await res.json();
    if (result.success) {
      closeModal('feedbackModal');
      showToast('Thank you! Feedback & Rating recorded.', 'success');
      loadInitialData();
    }
  } catch (err) {
    console.error('Error submitting feedback:', err);
  }
}

/* ==========================================================================
   UI Helpers & Modals
   ========================================================================== */
function setupModals() {
  // Modal backdrop click
  document.querySelectorAll('.modal-backdrop').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal(modal.id);
      }
    });
  });

  // Star rating clicks
  document.querySelectorAll('.star-rating .star').forEach(star => {
    star.addEventListener('click', () => {
      setStarRating(parseInt(star.dataset.val));
    });
  });

  // Forms
  document.getElementById('addVehicleForm')?.addEventListener('submit', handleAddVehicleSubmit);
  document.getElementById('otpVerifyForm')?.addEventListener('submit', handleOtpVerifySubmit);
  document.getElementById('paymentForm')?.addEventListener('submit', handlePaymentSubmit);
  document.getElementById('feedbackForm')?.addEventListener('submit', handleFeedbackSubmit);
  document.getElementById('reassignForm')?.addEventListener('submit', handleReassignSubmit);
}

function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.add('show');
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('show');
}

function openReassignModal(bookingId) {
  document.getElementById('reassignBookingId').value = bookingId;
  const select = document.getElementById('reassignProviderSelect');
  if (select) {
    select.innerHTML = state.allProviders.map(p => `
      <option value="${p.providerId}">${p.name} (${p.providerType}) - ${p.location}</option>
    `).join('');
  }
  openModal('reassignModal');
}

function renderBookingsHistory() {
  const container = document.getElementById('userBookingsHistory');
  if (!container) return;

  if (state.allBookings.length === 0) {
    container.innerHTML = `<p style="color:#6c757d; font-size:0.85rem;">No previous service records.</p>`;
    return;
  }

  container.innerHTML = state.allBookings.map(b => `
    <div style="background:#fff; border:1px solid #e9ecef; border-radius:8px; padding:12px; margin-bottom:10px;">
      <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
        <strong style="font-size:0.9rem;">#BK-${b.bookingId} • ${b.serviceType}</strong>
        <span class="badge ${getStatusBadgeClass(b.status)}">${b.status}</span>
      </div>
      <div style="font-size:0.8rem; color:#6c757d; margin-bottom:6px;">
        ${b.bookingDate} ${b.bookingTime} • ₹${parseFloat(b.totalAmount).toFixed(2)} (${b.paymentStatus})
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span style="font-size:0.78rem;">Provider: ${b.providerName}</span>
        ${b.status === 'COMPLETED' ? `<button class="btn btn-sm btn-outline" onclick="openInvoiceModal(${b.bookingId})">Invoice</button>` : ''}
      </div>
    </div>
  `).join('');
}

function renderProvidersList() {
  const provSelect = document.getElementById('providerProfileSelect');
  if (provSelect) {
    provSelect.innerHTML = state.allProviders.map(p => `
      <option value="${p.providerId}" ${p.providerId === state.providerId ? 'selected' : ''}>
        ${p.name} (${p.providerType})
      </option>
    `).join('');
  }
}

function getStatusBadgeClass(status) {
  switch (status?.toUpperCase()) {
    case 'COMPLETED': return 'badge-success';
    case 'IN_PROGRESS': return 'badge-warning';
    case 'ARRIVED': return 'badge-info';
    case 'EN_ROUTE': return 'badge-primary';
    case 'ASSIGNED': return 'badge-info';
    case 'CANCELLED': return 'badge-danger';
    default: return 'badge-warning';
  }
}

function showToast(msg, type = 'info') {
  const toast = document.createElement('div');
  toast.style.position = 'fixed';
  toast.style.bottom = '20px';
  toast.style.right = '20px';
  toast.style.padding = '12px 20px';
  toast.style.borderRadius = '8px';
  toast.style.color = '#fff';
  toast.style.fontWeight = 'bold';
  toast.style.fontSize = '0.9rem';
  toast.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
  toast.style.zIndex = '9999';
  toast.style.transition = 'all 0.3s ease';

  if (type === 'success') toast.style.background = '#2b8a3e';
  else if (type === 'error') toast.style.background = '#e03131';
  else toast.style.background = '#1971c2';

  toast.textContent = msg;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
